def build_base_headers(): return {'User-Agent':'locust-sample','Accept':'text/html'}
