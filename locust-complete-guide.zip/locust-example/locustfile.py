from locust import FastHttpUser, task, between
from utils.headers import build_base_headers

class ExampleUser(FastHttpUser):
    wait_time = between(1, 2)
    def on_start(self): self.client.base_url = "https://example.com"
    @task
    def load_homepage(self): self.client.get("/", headers=build_base_headers(), name="GET /")
