# Terraform — Locust on ECS Fargate

This module deploys Locust Master + Workers on ECS Fargate with:
- Cloud Map private DNS for worker→master
- Optional public NLB for web UI (port 80→8089)
- SSM Parameter Store secrets (API key + Cognito creds)
- CloudWatch Logs
- Worker autoscaling (target 60% CPU)

## Inputs
- `aws_region`, `vpc_id`, `private_subnet_ids`, `public_subnet_ids`
- `api_target_url` (your API Gateway stage URL)
- `image_uri` (ECR image with your Locust config)

## Quick Start
```bash
terraform init
terraform apply \
  -var='aws_region=eu-west-1' \
  -var='vpc_id=vpc-xxxxxxxx' \
  -var='private_subnet_ids=["subnet-a","subnet-b"]' \
  -var='public_subnet_ids=["subnet-c","subnet-d"]' \
  -var='api_target_url=https://abcd.execute-api.eu-west-1.amazonaws.com/prod' \
  -var='image_uri=123456789012.dkr.ecr.eu-west-1.amazonaws.com/locust-runner:latest'
```

After apply:
- If `enable_public_ui=true`, open the `master_ui_url` output in a browser.
- Otherwise, access the UI privately or run the master headless.
