def base_headers(): return {'User-Agent':'locust-ecs-fargate'}
