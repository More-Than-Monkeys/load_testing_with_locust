from locust import FastHttpUser, task, between

class PublicUser(FastHttpUser):
    wait_time=between(1,2)
    @task
    def t(self): self.client.get('/')
