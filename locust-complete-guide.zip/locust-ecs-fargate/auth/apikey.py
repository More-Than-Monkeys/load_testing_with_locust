import os
def api_key_headers(): return {'x-api-key':os.getenv('API_KEY','')}
